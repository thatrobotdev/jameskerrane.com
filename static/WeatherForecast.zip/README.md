# WeatherForecast

![Screenshot of the WeatherForecast app on an iPhone with a title that says "7-day Forecast". Underneath the title, a scrolling view with labeled dates (Mon, Tue, Wed, etc.) is shown with sun, rain, and snow icons. Text beneath each icon shows the high and low temperature for each day, with the high appearing in red when it is above 80 degrees. Below the scrolling view is a summary for the week with the average low, high, days of sun, and days of rain.](screenshot.png)

Tutorial project built while following Apple's [Develop in Swift Tutorials](https://developer.apple.com/tutorials/develop-in-swift).
