# ChatPrototype

![Screenshot of ChatPrototype app on an iPhone with the following conversation: "¡Holisssss!" (in a center-aligned yellow bubble with shadow), "¿Qué onda linda?" (In a center-aligned cyan bubble with similar styling to previous bubble, the rest of the conversation follows this pattern), "Nada mucho, solo probando Xcode ;))", "¡Buena suerte!", "Gracias, ¡adiós!", "¡Hasta luego!"](screenshot.png)

Tutorial project built while following Apple's [Develop in Swift Tutorials](https://developer.apple.com/tutorials/develop-in-swift).
