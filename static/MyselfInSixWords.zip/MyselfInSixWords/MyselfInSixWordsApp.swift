//
//  MyselfInSixWordsApp.swift
//  MyselfInSixWords
//
//  Created by James Kerrane on 6/3/24.
//

import SwiftUI

@main
struct MyselfInSixWordsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
