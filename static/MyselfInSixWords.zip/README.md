# MyselfInSixWords

![Screenshot of MyselfInSixWords app on an iPhone. An icon of a hand waving appears above the text, "Hello, world! Here are six words that describe me:". Beneath the sentence are six words with colored backgrounds. Hacker (with a red background), Brother (with a blue background), Learner (with a green background), Curious (with a cyan background), Dreamer (with a dark blue background), and Optimist (with a yellow background).](screenshot.png)

Tutorial project built while following Apple's [Develop in Swift Tutorials](https://developer.apple.com/tutorials/develop-in-swift).
